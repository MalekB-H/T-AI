# =============================
# TAXI RL PROJECT - ULTIMATE VERSION 🔥
# =============================

import gymnasium as gym
import numpy as np
import matplotlib.pyplot as plt
import time
import random
from collections import deque

def safe_input(prompt, default, cast_func):
    try:
        value = input(prompt)
        if value == "":
            return default
        return cast_func(value)
    except Exception:
        return default

STATE_SIZE = 500
ACTION_SIZE = 6

def random_agent(env, episodes):
    rewards, steps_list = [], []
    for _ in range(episodes):
        state, _ = env.reset()
        done = False
        total_reward, steps = 0, 0
        while not done:
            action = env.action_space.sample()
            state, reward, done, truncated, _ = env.step(action)
            done = done or truncated
            total_reward += reward
            steps += 1
        rewards.append(total_reward)
        steps_list.append(steps)
    return rewards, steps_list

def q_learning(env, episodes, alpha, gamma, epsilon):
    q_table = np.zeros((STATE_SIZE, ACTION_SIZE))
    rewards, steps_list = [], []
    for _ in range(episodes):
        state, _ = env.reset()
        done = False
        total_reward, steps = 0, 0
        while not done:
            if np.random.rand() < epsilon:
                action = env.action_space.sample()
            else:
                action = np.argmax(q_table[state])
            next_state, reward, done, truncated, _ = env.step(action)
            done = done or truncated
            q_table[state, action] += alpha * (
                reward + gamma * np.max(q_table[next_state]) - q_table[state, action]
            )
            state = next_state
            total_reward += reward
            steps += 1
        epsilon = max(0.01, epsilon * 0.995)
        rewards.append(total_reward)
        steps_list.append(steps)
    return q_table, rewards, steps_list

def dqn(env, episodes, gamma=0.99, epsilon=1.0):
    q_table = np.zeros((STATE_SIZE, ACTION_SIZE))
    memory = deque(maxlen=2000)
    rewards, steps_list = [], []
    for _ in range(episodes):
        state, _ = env.reset()
        done = False
        total_reward, steps = 0, 0
        while not done:
            if random.random() < epsilon:
                action = env.action_space.sample()
            else:
                action = np.argmax(q_table[state])
            next_state, reward, done, truncated, _ = env.step(action)
            done = done or truncated
            memory.append((state, action, reward, next_state))
            if len(memory) > 32:
                batch = random.sample(memory, 32)
                for s, a, r, ns in batch:
                    q_table[s, a] = r + gamma * np.max(q_table[ns])
            state = next_state
            total_reward += reward
            steps += 1
        epsilon = max(0.05, epsilon * 0.995)
        rewards.append(total_reward)
        steps_list.append(steps)
    return q_table, rewards, steps_list

def visualize_agent(env, q_table):
    try:
        env = gym.make("Taxi-v3", render_mode="human")
    except Exception:
        print("Fallback to text mode")
        env = gym.make("Taxi-v3", render_mode="ansi")
    state, _ = env.reset()
    done = False
    print("\nVisualizing agent...")
    while not done:
        action = np.argmax(q_table[state])
        state, _, done, truncated, _ = env.step(action)
        done = done or truncated
        try:
            frame = env.render()
            if isinstance(frame, str):
                print(frame)
        except:
            pass
        time.sleep(0.3)
    env.close()

def generate_report(results):
    with open("report.txt", "w") as f:
        f.write("=== TAXI RL REPORT ===\n\n")
        for algo, (steps, rewards) in results.items():
            f.write(f"{algo}:\n")
            f.write(f"  Avg Steps: {np.mean(steps):.2f}\n")
            f.write(f"  Avg Reward: {np.mean(rewards):.2f}\n\n")
    print("Report generated")

def plot_results(data, title):
    import matplotlib.pyplot as plt
    plt.figure()
    for label, values in data.items():
        plt.plot(values, label=label)
    plt.legend()
    plt.title(title)
    plt.show()

def main():
    print("Taxi RL Project")
    episodes = safe_input("Episodes (5000): ", 5000, int)
    env = gym.make("Taxi-v3")
    r_rewards, r_steps = random_agent(env, episodes)
    q_table, q_rewards, q_steps = q_learning(env, episodes, 0.1, 0.99, 0.1)
    _, dqn_rewards, dqn_steps = dqn(env, episodes)
    print("Results:")
    print("Q-learning steps:", np.mean(q_steps))
    plot_results({"Q": q_rewards}, "Rewards")
    if safe_input("Visualize? (1/0): ", 0, int) == 1:
        visualize_agent(env, q_table)
    generate_report({
        "Random": (r_steps, r_rewards),
        "Q": (q_steps, q_rewards),
        "DQN": (dqn_steps, dqn_rewards)
    })

if __name__ == "__main__":
    main()
