# Taxi RL Project

## Installation
pip install -r requirements.txt

## Run
python main.py

## Features
- Q-Learning
- DQN (simplified)
- Visualization
- Auto report
